# BlogVerse
## Installing MongoDb(set it up to get the connecting key) and Node js,Hyper terminal
 Install nodejs  
 Install nodemon globally  
 install mongoDb shell and compass,Hyper  
## Installing Python and Transformers Library
 Install python  
## Deploying the website
 - Download the zip file from github repository and extract this file.  
 - Go to google cloud console and create a project, enable `Google+ API` service go through the general process to get `CLIENT_ID` , `CLIENT_SECRET`  
 - Go to TinyMCE website and get the API key for it by creating an account.  
 - open this folder in hyper and in any of your editer.  
 - Place all your connecting keys of `MONGODB`,`GOOGLE+ API`(CLIENT_ID,CLIENT_SECRET),`TINYMCE API` in the key.js accordingly  
 - run `npm i` command in your hyper and all your dependencies will be installed.  
 - run `pip install transformers` command to install transformers.  
