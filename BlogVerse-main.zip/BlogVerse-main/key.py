import sys
from keybert import KeyBERT
from bs4 import BeautifulSoup
from sentence_transformers import SentenceTransformer



html =sys.stdin.readline()
 
# html="""<div class="">
# <h1 id="715f" class="pw-post-title ud fi ue ak iz uf ug uh ui uj uk ul um un uo up uq ur us ut uu uv uw ux uy uz bo" data-selectable-paragraph="">What We&rsquo;re Reading: Aren&rsquo;t humans amazing sometimes?</h1>
# </div>
# <div class="">
# <h2 id="dba4" class="pw-subtitle-paragraph va fi ue ak b vb vc vd ve vf vg vh vi ns nt vj nx ny vk oc od vl ah" data-selectable-paragraph="">A few stories you may have missed this week</h2>
# </div>
# <p id="5277" class="pw-post-body-paragraph vm vn ue oi b vo vp ve vq vr vs vh vt vu vv vw vx vy vz wa wb wc wd we wf wg kq bo" data-selectable-paragraph="">Humans are amazing sometimes. In the midst of *gestures broadly* everything happening in the world right now, it&rsquo;s worth coming back to this simple truth from time to time, and I wanted to share two stories from Medium this week that illustrate the point in two very different ways.</p>
# <p class="pw-post-body-paragraph vm vn ue oi b vo vp ve vq vr vs vh vt vu vv vw vx vy vz wa wb wc wd we wf wg kq bo" data-selectable-paragraph="">The first is from&nbsp;</p>
# <div class="bq qt">
# <div>
# <div class="bq" aria-hidden="false" aria-describedby="227" aria-labelledby="227"><a class="uc rd jr" href="https://medium.com/u/af9e0e9cc2d7?source=post_page-----94f8a3b37394--------------------------------" target="_blank" rel="noopener">Amby Burfoot</a></div>
# </div>
# </div>
# <p id="45ed" class="pw-post-body-paragraph vm vn ue oi b vo vp ve vq vr vs vh vt vu vv vw vx vy vz wa wb wc wd we wf wg kq bo" data-selectable-paragraph="">, writing about the Boston Marathon (which will be held this year on April 17). Burfoot won the marathon in 1968, a massive achievement in itself, but&nbsp;<a class="ax gz" href="https://medium.com/runners-life/the-author-won-the-1968-boston-marathon-and-ran-many-more-after-the-bombs-everything-changed-d4ab2f44205" rel="noopener">his story is about the many times he ran it afterwards, and especially how the race changed after the 2013 bombing</a>. He ends with the hard won wisdom that every mile is a gift: &ldquo;After all, I don&rsquo;t know if I&rsquo;ll ever be here again. Life gives us no guarantees. But I do know for sure that right now there is no other place in the world I would rather be.&rdquo;</p>
# <p class="pw-post-body-paragraph vm vn ue oi b vo vp ve vq vr vs vh vt vu vv vw vx vy vz wa wb wc wd we wf wg kq bo" data-selectable-paragraph="">The second story takes us from the realm of sports to mathematics, from the body to the mind. &ldquo;<a class="ax gz" href="https://keith-mcnulty.medium.com/heres-how-two-new-orleans-teenagers-found-a-new-proof-of-the-pythagorean-theorem-b4f6e7e9ea2d" rel="noopener">Here&rsquo;s How Two New Orleans Teenagers Found a New Proof of the Pythagorean Theorem</a>&rdquo; outlines how Calcea Johnson and Ne&rsquo;Kiya Jackson may have found a novel way to use trigonometry to prove the 2,500+ year old theorem. There&rsquo;s still more to come &mdash; Johnson and Jackson have yet to publish their proof &mdash; but as writer&nbsp;</p>
# <div class="bq qt">
# <div>
# <div class="bq" aria-hidden="false" aria-describedby="248" aria-labelledby="248"><a class="uc rd jr" href="https://medium.com/u/a859aab532a0?source=post_page-----94f8a3b37394--------------------------------" target="_blank" rel="noopener">Keith McNulty</a></div>
# </div>
# </div>
# <div><div class="bq" aria-hidden="false" aria-describedby="229" aria-labelledby="229"><a class="uc rd jr" href="https://medium.com/u/d00bc5bb7954?source=post_page-----94f8a3b37394--------------------------------" target="_blank" rel="noopener">Thomas Smith</a></div>
# </div></div><p id="f8f0" class="pw-post-body-paragraph vm vn ue oi b vo vp ve vq vr vs vh vt vu vv vw vx vy vz wa wb wc wd we wf wg kq bo" data-selectable-paragraph="">&nbsp;about&nbsp;<a class="ax gz" href="https://blog.medium.com/how-an-artificial-intelligence-expert-successfully-launched-a-new-ai-publication-on-medium-ae5e119a5313" rel="noopener">his approach to publishing and writing on Medium</a>.</p>"""
soup = BeautifulSoup(html, 'html.parser')
doc=soup.get_text()
sentence_model = SentenceTransformer("paraphrase-MiniLM-L6-v2")
kw_model = KeyBERT('distilbert-base-nli-mean-tokens')
keywords = kw_model.extract_keywords(doc, keyphrase_ngram_range=(1, 1), stop_words=None,top_n=3,use_mmr=True,diversity=0.5)
output_keywords = []
for keyword in keywords:
      if isinstance(keyword, tuple):
        output_keywords.append(keyword[0])
sys.stdout.write(str(output_keywords))
sys.stdout.flush()
